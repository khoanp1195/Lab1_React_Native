import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated } from 'react-native';
import { index } from "cheerio/lib/api/traversing";
import { windowWidth } from '../config/font';

// @ts-ignore
const ToggleHeader = ({ changeIndex, text1, text2, styleContainer }) => {
    const [selectedIndex, setSelectedIndex] = useState(0);
    const handleSelect = (index: React.SetStateAction<number>) => {
        setSelectedIndex(index);
        changeIndex(index);
    };


    const slideAnimation = useRef(new Animated.Value(0)).current;
    useEffect(() => {
        Animated.timing(slideAnimation, {
            toValue: selectedIndex,
            duration: 300, // Adjust the duration as needed
            useNativeDriver: true
        }).start();
    }, [selectedIndex]);

    
    return (
        <View style={styles.container}>
        <View style={[styles.tab, selectedIndex === 0 && styles.selectedTab]}>
            <TouchableOpacity style={{ width: '100%', justifyContent: 'center', alignItems: 'center' }} onPress={() => handleSelect(0)}>
                <Text style={[selectedIndex === 0 ? styles.selectedText : styles.text]}>{text1}</Text>
            </TouchableOpacity>
        </View>
        <View style={[styles.tab, selectedIndex === 1 && styles.selectedTab]}>
            <TouchableOpacity style={{ width: '100%', justifyContent: 'center', alignItems: 'center' }} onPress={() => handleSelect(1)}>
                <Text style={[selectedIndex === 1 ? styles.selectedText : styles.text]}>{text2}</Text>
            </TouchableOpacity>
        </View>
    </View>
        //how to set animation slide left to right and right to left  in React Native with this code
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        width: '100%', // Set container width to window width
        height: 47,
        alignSelf:'center',
        backgroundColor:'#F2F3F7',
        borderRadius:15
  
    },
    tab: {
        flex: 1, // Each tab takes up half of the container
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius:15,
        marginLeft:4,
        marginRight:4
    },
    selectedTab: {
        backgroundColor: 'white', // Example background color for selected tab,
        alignSelf:'center',
        height:40,
     
    },
    text: {
        color: 'black', // Example text color for unselected tab
    },
    selectedText: {
        color: '#006885', // Example text color for selected tab
        fontWeight:'600'
    },
});

export default ToggleHeader;
