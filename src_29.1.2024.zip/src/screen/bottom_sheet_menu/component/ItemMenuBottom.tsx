import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';

// @ts-ignore
const ItemMenuBottom = ({ onPress, pathImageLeft, rightView, text, showLine, textColor }) => {
    return (
        onPress ? (
            <TouchableOpacity onPress={onPress}>
                <MenuItem
                    pathImageLeft={pathImageLeft}
                    rightView={rightView}
                    text={text}
                    showLine={showLine}
                    textColor={textColor}
                />
            </TouchableOpacity>
        ) : (
            <MenuItem
                pathImageLeft={pathImageLeft}
                rightView={rightView}
                text={text}
                showLine={showLine}
                textColor={textColor}
            />
        )
    );
};
const { width } = Dimensions.get('window');
// @ts-ignore
const MenuItem = ({ pathImageLeft, rightView, text, showLine, textColor }) => {
    return (
        <View style={styles.container}>
            <View style={styles.leftContainer}>
                <Image source={pathImageLeft} style={styles.leftImage} />
            </View>
            <View style={styles.centerContainer}>
                <Text style={[styles.centerText, { color: textColor }]}>{text}</Text>
                {rightView && (
                    <View style={styles.rightViewContainer}>
                        {rightView}
                    </View>
                )}
            </View>
            {showLine ? <View style={styles.line} /> : <View style={styles.lineHidden} />}
        </View>
    );
};
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        padding:8,
        flex:1
    },
    leftContainer: {
        marginRight: 16,
    },
    leftImage: {
        width: 20,
        height: 20,
        resizeMode: 'contain',
        marginTop:6

    },
    centerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    centerText: {
        fontSize: 14,
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        width: '92%',
    },
    
    rightViewContainer: {
       
    },
    line: {
        marginTop: 36,
        height: 1,
        width: '99%',
        backgroundColor: '#C0C0C0',
        marginLeft:'-100%',
        borderWidth:0.1
    },
    lineHidden:{
        marginTop: 35,
        height: 1,
        width: '95%',
        backgroundColor: 'white',
    }
});

export default ItemMenuBottom;
