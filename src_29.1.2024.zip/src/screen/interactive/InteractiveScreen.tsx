import {Image, Platform, Text, TouchableOpacity, View} from "react-native";
import {ListLoadMore} from "components/ListLoadMore";
import {getDocumentInteractive} from "services/api/apiProvider";
import {useDispatch, useSelector} from "react-redux";
import {currentUserStore} from "../../config/constants";
import React from "react";
import {FastImageCustom} from "components/FastImageCustom";
import FastImage from "react-native-fast-image";
import {dimensWidth} from "../../config/font";
import {format_dd_mm_yy, format_yy_mm_mm_dd_hh, getParameterUrlDoc, isNullOrEmpty} from "../../utils/function";
import {AppBarCustom} from "components/AppBarCustom";
import {DocumentInteractive} from "services/database/models/DocumentInteractive";
import NetInfo from "@react-native-community/netinfo";
import {goToDocumentDetail} from "navigation/goToDetailNavigation";
import { SafeAreaView } from "react-native-safe-area-context";
import { hideBottomSheet, showBottomSheet } from "../../../src/redux/bottom_sheet/reducer";

// @ts-ignore
export const InteractiveScreen = ({navigation}) => {
    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);

    const dispatch = useDispatch();
    // @ts-ignore
    const translations = useSelector((state) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    const langId = currentLanguage === 'en' ? 1033 : 1066;
    // @ts-ignore
    const {isConnected} = useSelector((state) => state.netInfo);
    const { isVisible } = useSelector((state: any) => state.bottomSheet);
    // @ts-ignore
    const itemRender = ({item, index}) => {
        // @ts-ignore
        return <TouchableOpacity onPress={() => goToDocumentDetail(navigation,item.ResourceUrl,isConnected,false)}>
            <View
                style={{backgroundColor: index % 2 == 0 ? '#F1FAFF' : 'white', flexDirection: 'row', width: '100%', paddingHorizontal: 20, paddingVertical: 10}}>
                <FastImageCustom urlOnline={item.Thumbnail}
                                 defaultImage={require('assets/images/icon_document_default.png')}
                                 styleImg={{height: 45, width: 30, borderRadius: dimensWidth(0)}}
                                 resizeMode={FastImage.resizeMode.stretch}/>
                <View style={{flex: 1}}>
                    <Text numberOfLines={1} style={{width:'100%'}} >{item.Title}</Text>
                    <Text style={{color:'#7B7B7B',marginTop:15}}>{item.Type}</Text>
                </View>
                {
                    !isNullOrEmpty(item.Created)&&(<View>
                        <Text style={{color:'#7B7B7B',marginTop:36,fontSize:12}}>{format_yy_mm_mm_dd_hh(item.Created)}</Text>
                    </View>)
                }
            </View>
        </TouchableOpacity>
    }
    const getData = async (limit: number, offet: number, isOnline: any) => {
        if(isOnline)
        {
            const data = await getDocumentInteractive(langId, "Offset,Limit,LangId", offet, limit);
            if(data !=null)
            {
                DocumentInteractive.insertOrUpdateAll(data);
            }
            return data;
        }
        else
        {
            return DocumentInteractive.getAll(limit,offet);
        }
    }
    const isShowModal = async () => {
        dispatch(isVisible ? hideBottomSheet() : showBottomSheet());
    }

    return <View style={{height:'100%',width:'100%',backgroundColor:'white'}}>
        <View style={{flex: 1, flexDirection: 'column'}}>
        <AppBarCustom onPress={Platform.OS === 'ios' ? isShowModal : null} navigation={navigation} title={currentTranslations.interactive_document} RightControl={null}/>
        {/* <View style={{width:'100%',height:0.75,backgroundColor:'grey'}}/> */}
        <ListLoadMore numColumn={1} callData={getData} ItemRenderFlatlist={itemRender} limit={15} enableMoreData={true}/>
    </View>
    </View>
}

