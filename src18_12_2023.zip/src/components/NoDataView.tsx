import React, {FC} from 'react';
import {
  Image,
  ImageBackground,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {FontSize} from '../config/font';
import colors from '../config/colors';
import {useDispatch, useSelector} from "react-redux";
import {ThunkDispatch} from "redux-thunk";

interface Props {
  onRetryPress?: () => any;
  isHomeView: Boolean
}

const NoDataView: FC<Props> = ({isHomeView,...props}: Props) => {
  // @ts-ignore
  const currentLanguage = useSelector((state) => state.languages.currentLanguage);
  let isHomeVieww = isHomeView
  // @ts-ignore
  const translations = useSelector((state) => state.languages.translations);
  const currentTranslations = translations[currentLanguage];
  return (
    <View style={{ 
      marginTop:  isHomeVieww ? '10%':'85%',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',}}>
      <Image source={require('assets/images/icon_no_data.png')} style={{width:300,height:150,resizeMode: 'stretch' }}/>
      <Text  style={styles.textNoData}>{currentTranslations.nodata}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  viewNoData: {
    marginTop: '65%',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textNoData: {
    fontSize: 14,
    fontStyle:'italic',
    color: '#006885',
    marginTop: '6%',
    height:100
  },
});

export default React.memo(NoDataView);
