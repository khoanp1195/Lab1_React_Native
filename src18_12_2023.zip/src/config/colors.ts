const colors = {
    white: '#ffffff',
    black: '#000000',
    orange: '#DBA410',
    red: 'red',
    DarkCyan: '#006885',
    text_grey26: '#262626',
    text_grey_bc: '#BCBCBC',
    bottomtab_inactive_grey: '#C7D2DD',
    grey_co: '#C0C0C0'
};

export default colors;
