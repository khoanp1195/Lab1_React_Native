import DeviceInfo from 'react-native-device-info';
import messaging from "@react-native-firebase/messaging";
import {Platform, PlatformIOSStatic} from "react-native";
export async function getDeviceInfo() {
    const devicePushToken=await messaging().getToken();
    let deviceOS;
    if (Platform.OS === 'ios') {
        const platformIOS = Platform as PlatformIOSStatic
        if(platformIOS.isPad)
        {
            deviceOS=4;
        }
        else
        {
            deviceOS=2;
        }
    }
    else
    {
        deviceOS=1
    }
    return JSON.stringify({
        DeviceInfo:{
            AppVersion: DeviceInfo.getReadableVersion(),
            DeviceId: DeviceInfo.getDeviceId(),
            DeviceModel: DeviceInfo.getModel(),
            DeviceName: await DeviceInfo.getDeviceName(),
            DeviceOS: deviceOS,
            DeviceOSVersion: DeviceInfo.getSystemVersion(),
            DevicePushToken: devicePushToken,
        }
    });
}
