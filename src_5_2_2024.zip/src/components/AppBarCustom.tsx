import { Alert, Image, PermissionsAndroid, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React, { useState } from "react";
import RNHTMLtoPDF from 'react-native-html-to-pdf';
import { Platform, NativeModules } from 'react-native';
import Share from 'react-native-share';
import { PERMISSIONS, RESULTS, check, request } from "react-native-permissions";

// @ts-ignore
export const AppBarCustom = ({ title, navigation, RightControl, onPress, isOffline, localPath, url, documentOffline }) => {

    const generatePDF = async (html: string) => {
        try {
            Share.open({
                url: localPath,
            });
        } catch (error) {
            console.error('Error generating PDF:', error);
        }
    };
    
    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.touch} onPress={() => {
                if (onPress == null) {
                    navigation.pop();
                }
                else {
                    if (Platform.OS === 'ios') {
                        navigation.pop();
                    }
                    onPress();
                }
            }}>
                <Image
                    style={styles.image}
                    source={require('assets/images/icon_back.png')}
                    resizeMode="contain"
                />
            </TouchableOpacity>
            <Text style={styles.text}>{title}</Text>
            {RightControl != null && (
                <RightControl />
            )}
            {
                isOffline ? (
                    <TouchableOpacity onPress={() => {
                        generatePDF(localPath)
                    }}>
                        <Image
                            style={styles.img_dowload}
                            source={require('assets/images/icon_dowload_offline.png')}
                            resizeMode="contain"
                        />
                    </TouchableOpacity>
                ) : null
            }
        </View>
    );
};


const styles = StyleSheet.create({
    text: {
        color: '#006885',
        fontSize: 20,
        fontFamily: 'heritage_bold',
        lineHeight: 24,
        flex: 1,
        fontWeight: '600'
    },
    image: {
        height: 30,
        width: 30,
        marginLeft: 10
    },
    touch: {
        padding: 6
    },
    rightControl: {
        // Tùy chỉnh kiểu dáng của control bên phải ở đây
    },
    container: {
        height: 50,
        width: '100%',
        backgroundColor: 'white',
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row'
    },
    img_dowload: {
        height: 30,
        width: 30,
        marginRight: 20
    }
});
