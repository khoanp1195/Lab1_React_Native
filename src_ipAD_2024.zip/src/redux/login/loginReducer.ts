import {createSlice, createAsyncThunk} from '@reduxjs/toolkit';
import {callLogin} from "services/api/apiProvider";


export const login = createAsyncThunk<
    string,
    { username: string; password: string;  }
>('login/login', async ({username, password}) => {
    return await callLogin(username, password);
});

export interface AuthState {
    isAuth: boolean;
    isFirst: boolean;
    error: string | null;
    isLoading: boolean
}

const initialState: AuthState = {
    isAuth: false,
    error: null,
    isLoading: true,
    isFirst: true
};
const loginSlice = createSlice({
    name: 'login',
    initialState,
    reducers: {
        re_init_state_login: (state, action) => {
            state.isFirst = false;
            state.isAuth = false;
            state.error = null;
            state.isLoading = false;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(login.pending, state => {
                state.isFirst = false;
                state.isAuth = false;
                state.isLoading = true;
            })
            .addCase(login.fulfilled, (state, action) => {
                state.isFirst = true;
                state.isAuth = true;
                state.error = null;
                state.isLoading = false;
            })
            .addCase(login.rejected, (state, action) => {
                state.isFirst = false;
                state.isAuth = false;
                state.error = action.error.message || 'Login failed';
                state.isLoading = false;
            });
    },
});
const {reducer} = loginSlice;
export const {re_init_state_login}=loginSlice.actions;
export default reducer;

