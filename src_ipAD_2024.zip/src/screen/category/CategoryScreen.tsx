import { Dimensions, FlatList, ImageBackground, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React, { useEffect, useState } from "react";
import { DocumentAreaCategory } from "services/database/models/DocumentAreaCategory";
import { currentUserStore } from "../../config/constants";
import { FastImageCustom } from "components/FastImageCustom";
import { getAllMasterData } from "services/api/apiProvider";
import { getModified, saveModified } from "../../utils/asyncStrorage";
import { FavoriteFolder } from "services/database/models/FavoriteFolder";
import { DocumentType } from "services/database/models/DocumentType";
import { addPositionStayCategory } from "../../redux/category/reducer";
import { useDispatch, useSelector } from "react-redux";
import { dimensWidth, windowWidth } from "../../config/font";
import FastImage from "react-native-fast-image";
import { setChildCategory, setIsAlreadySwitchSite } from "../../redux/app_bar_dasboard/reducer";
import { Animations, getCurrentTimeFormatted } from "../../utils/function";
import * as Animatable from 'react-native-animatable';
import SortableGridView from 'react-native-sortable-gridview'
export const CategoryScreen = () => {
    const dispatch = useDispatch();
    const [data, setData] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const { currentSite } = useSelector((state: any) => state.sub_site);
    const { isAlreadySwitchSite } = useSelector(
        (state: any) => state.appbar
    );
    const updateIsFirst = () => ({
        type: 'UPDATE_IS_FIRST',
        payload: false,
    });
    const { isFirst } = useSelector(
        (state: any) => state.login
    );
    const dimensWidth = (percentage) => {
        const screenWidth = Dimensions.get('window').width;
        return (screenWidth * percentage) / 100;
      };
      
    //how to update isFirst == false when access this view in react native

    const animation = Animations[Math.floor(Math.random() * Animations.length)]
    console.log('isAlreadySwitchSite - here ' + isAlreadySwitchSite)
    const fetchData = async () => {
        DocumentAreaCategory.getParentCategories().then((values) => {
            // @ts-ignore
            setData(values);
            setRefreshing(false); // Stop the refreshing indicator
        });
    };

    useEffect(() => {
        onRefresh()
    }, [dispatch, currentLanguage, currentSite]);

    const onRefresh = async () => {
        try {
            dispatch(updateIsFirst());
            setRefreshing(true); 
            const values = await getAllMasterData("DocumentAreaCategory,FavoriteFolder,DocumentType", await getModified());
            DocumentAreaCategory.insertOrUpdateAll(values.DocumentAreaCategory);
            FavoriteFolder.insertOrUpdateAll(values.FavoriteFolder);
            DocumentType.insertOrUpdateAll(values.DocumentType);
            saveModified(getCurrentTimeFormatted());
            fetchData(); 
        } catch (error) {
            console.error("Error during onRefresh:", error);
        } finally {
            setRefreshing(false); 
        }
    };
    


    

    //add 13.12 add loaddata first login
    const LoadDataFirstLogin = async () => {
        setRefreshing(true); // Start the refreshing indicator
        getAllMasterData("DocumentAreaCategory,FavoriteFolder,DocumentType", await getModified()).then(values => {
            DocumentAreaCategory.insertOrUpdateAll(values.DocumentAreaCategory);
            FavoriteFolder.insertOrUpdateAll(values.FavoriteFolder);
            DocumentType.insertOrUpdateAll(values.DocumentType);
            saveModified(getCurrentTimeFormatted());
            fetchData(); // Fetch data again when refreshing
        });

    };

    return (
        <ImageBackground source={require('assets/images/background.png')} style={styles.imgBackground}>

            <FlatList
                contentContainerStyle={{marginLeft:'6%'}}
                data={data}
                numColumns={5}
                renderItem={({ item, index }) => (
                    <TouchableOpacity onPress={() => {
                        dispatch(setChildCategory(true))
                        dispatch(addPositionStayCategory(item))
                    }} style={{ marginLeft: '-6.5%',marginBottom:'3%'}} >
                        <TouchableOpacity style={[styles.item, { backgroundColor: '#E2F9FF' }]}
                        >
                            <View style={styles.text}>
                                <FastImage
                                    defaultSource={require('assets/images/icon_thumbnail_category_default.png')}
                                    style={styles.image}
                                    source={{ uri: (item["Image"] && JSON.parse(item["Image"]).Path) ? JSON.parse(item["Image"]).Path : 'null' }}
                                />
                            </View>
                        </TouchableOpacity>
                        <View >
                            <View style={{ marginTop: 122, marginLeft: '8%' }}>
                                <Text style={[{
                                    top: '50%', width: 140,
                                    color: item.color, position: 'absolute', marginLeft: '9%',
                                    textAlign: 'center'
                                }]} numberOfLines={1}>
                                    {currentLanguage !== 'en' ? item["Title"] : item["TitleEN"]}
                                </Text>
                                <Text style={[{ height: 50, marginTop: 89, color: 'gray', width: 200, textAlign: 'center' }]}
                                    numberOfLines={2}>{item["Description"]}</Text>
                            </View>
                        </View>

                    </TouchableOpacity>
                )}


                keyExtractor={({ PrimaryKey }) => {
                    return PrimaryKey;
                }}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                    />
                }
            />
        </ImageBackground>
    );
};

const styles = StyleSheet.create({
    imageContainer: {
        flexDirection: 'row',
        backgroundColor: 'white',
        borderRadius: 3,
        width: 185,
        height: 270,
        borderColor: 'lightgray',
        borderWidth: 0.5,
        position: 'absolute',
    },
    imgBackground: {
        height: '100%',
        width: "100%",
        alignItems:'center'
    },
    image: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        alignContent: 'center',
        elevation: 4,
        height: 120,
        width: 130,
        borderRadius:15,
    },
    title: {
        color: 'black',
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center'
    },
    description: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center',
        height: 50,
        color: '#7B7B7B',
        width: '80%'
    },
    container: {
        flex: 1,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    gridItem: {
        flexDirection: 'row',
        backgroundColor: 'rgba(0, 0, 0, 0)',
        marginHorizontal: dimensWidth(15),
        borderRadius: 5,
        width: 200,
        height: 250,

        paddingHorizontal: '6.6%',
        marginLeft: 31,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
    },
    centeredItem: {
        alignSelf: 'center',
    },
    text: {
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center',   
    },
    item: {
        borderRadius: 10,
        shadowColor: "#000",
        flexDirection: 'column',
        shadowOffset: {
          width: 5,
          height: 5,
        },
        shadowOpacity: 0.5,
        shadowRadius: 3.84,
        elevation: 5,
        backgroundColor: 'white',
        position: 'absolute',
        width: 150,
        height: 160,
        top: 0,
        left: '17%',
        right: 0,
        bottom: 0,
        marginTop: 20,
        justifyContent: 'center',
        alignItems: 'center',
 
      },
      
});
