import { FlatList, ImageBackground, RefreshControl, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React, { useEffect, useState } from "react";
import { DocumentAreaCategory } from "services/database/models/DocumentAreaCategory";
import { currentUserStore } from "../../config/constants";
import { FastImageCustom } from "components/FastImageCustom";
import { getAllMasterData } from "services/api/apiProvider";
import { getModified, saveModified } from "../../utils/asyncStrorage";
import { FavoriteFolder } from "services/database/models/FavoriteFolder";
import { DocumentType } from "services/database/models/DocumentType";
import { useDispatch, useSelector } from "react-redux";
import { dimensWidth, windowWidth } from "../../config/font";
import { setChildFavorite, setIsAlreadySwitchSite, setIsAlreadySwitchSiteFav } from "../../redux/app_bar_dasboard/reducer";
import { addPositionStayFavorite } from "../../redux/favorite/reducer";
import { Animations, getCurrentTimeFormatted } from "../../utils/function";
import * as Animatable from 'react-native-animatable';
import FastImage from "react-native-fast-image";

export const FavoriteScreen = () => {
    const dispatch = useDispatch();
    const [data, setData] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const currentLanguage = useSelector((state: any) => state.languages.currentLanguage);
    const { currentSite } = useSelector((state: any) => state.sub_site);
    const { isAlreadySwitchSiteFav } = useSelector(
        (state: any) => state.appbar
    );
    const fetchData = () => {
        // Simulate fetching data from an API, replace with your actual data fetching logic
        FavoriteFolder.getParentFavorites().then((values) => {
            // @ts-ignore
            setData(values);
            setRefreshing(false); // Stop the refreshing indicator
        });
    };
    console.log("isAlreadySwitchSiteFav - here " + isAlreadySwitchSiteFav)
    useEffect(() => {
        if (isAlreadySwitchSiteFav) {
            FavoriteFolder.getParentFavorites().then((values) => {
                // @ts-ignore
                setData(values);
                setRefreshing(false); // Stop the refreshing indicator
            });
            setTimeout(() => {
                dispatch(setIsAlreadySwitchSiteFav(false));
            }, 5000);
        }
        else {
        }
    }, [isAlreadySwitchSiteFav, currentSite, data]);


    useEffect(() => {
        onRefresh()
        // fetchData();
    }, [currentSite]);

    const onRefresh = async () => {
        setRefreshing(true); // Start the refreshing indicator
        getAllMasterData("DocumentAreaCategory,FavoriteFolder,DocumentType", await getModified()).then(values => {
            DocumentAreaCategory.insertOrUpdateAll(values.DocumentAreaCategory);
            FavoriteFolder.insertOrUpdateAll(values.FavoriteFolder);
            DocumentType.insertOrUpdateAll(values.DocumentType);
            saveModified(getCurrentTimeFormatted());
            fetchData(); // Fetch data again when refreshing
        });

    };
    const animation = Animations[Math.floor(Math.random() * Animations.length)]
    return (
        <ImageBackground source={require('assets/images/background.png')} style={styles.imgBackground}>
              <FlatList
                contentContainerStyle={{marginLeft:'6%' }}
                data={data}
                numColumns={5}
                renderItem={({ item, index }) => (
                    <TouchableOpacity style={{ marginLeft: '-6.5%',marginBottom:'3%' }} onPress={() => {
                        dispatch(setChildFavorite(true))
                        dispatch(addPositionStayFavorite(item))
                    }}>
                                   <TouchableOpacity style={[styles.item, { backgroundColor: '#E2F9FF' }]}
                      >
                        <View style={styles.text}>
                            <FastImage
                                defaultSource={require('assets/images/icon_thumbnail_category_default.png')}
                                style={styles.image}
                                source={{ uri: (item["Image"] && JSON.parse(item["Image"]).Path) ? JSON.parse(item["Image"]).Path : 'null' }}
                            />
                        </View>
                    </TouchableOpacity>
                    <View > 
                    <View style={{ marginTop: 122, marginLeft: '8%'}}>
                        <Text style={[{ top: '50%', width: 140,
                         color: item.color, position: 'absolute',marginLeft: '9%',
                          textAlign: 'center' }]} numberOfLines={1}>
                            {currentLanguage !== 'en' ? item["Title"] : item["Title"]}
                        </Text>
                        <Text style={[{ height: 50, marginTop: 89, color: 'gray', width: 200, textAlign: 'center' }]}
                            numberOfLines={2}>{item["Description"]}</Text>
                    </View>
                    </View>

                    </TouchableOpacity>
                )}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                    />
                }
            />
        </ImageBackground>
    );
};

const styles = StyleSheet.create({
    imageContainer: {
        flexDirection: 'row',
        backgroundColor: 'white',
        borderRadius: 3,
        width: 185,
        height: 270,
        borderColor: 'lightgray',
        borderWidth: 0.5,
        position: 'absolute',
    },
    text: {
        justifyContent: 'center',
        alignContent: 'center',
        alignItems: 'center'
    },
    item: {
        borderRadius: 5,
        shadowColor: "#000",
        flexDirection: 'column',
        shadowOffset: {
            width: 5,
            height: 5,
        },
        shadowOpacity: 0.5,
        shadowRadius: 3.84,
        elevation: 5,
        backgroundColor: 'white',
        position: 'absolute',
        width: ' 50%',
        height: 160,
        top: 0,
        left: '17%',
        right: 0,
        bottom: 0,
        marginTop: 20,
        justifyContent: 'center',
        alignItems: 'center',
        alignContent: 'center'

    },
    imgBackground: {
        height: '100%',
        width: "100%"
    },
    image: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        height: dimensWidth(40),
        width: dimensWidth(40), alignContent: 'center',
        elevation: 4,
        borderRadius: 8,
    },
    title: {
        color: 'black',
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: '-15%',
        textAlign: 'center'
    },
    description: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        marginTop: 10,
        textAlign: 'center',
        height: 50,
        color:'#7B7B7B',
        width:'80%'
    },
    container: {
        flex: 1,
        height: '100%',
        width: '100%',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    gridItem: {
        width: windowWidth / 2,
        height: 220,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: -20,
    },
    centeredItem: {
        alignSelf: 'center',
    },
});
