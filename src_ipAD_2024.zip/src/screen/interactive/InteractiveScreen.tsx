import {Image, ScrollView, StyleSheet, Text, TouchableOpacity, View} from "react-native";
import {ListLoadMore} from "components/ListLoadMore";
import {getDocumentInteractive} from "services/api/apiProvider";
import {useDispatch, useSelector} from "react-redux";
import {currentUserStore} from "../../config/constants";
import React, { useCallback } from "react";
import {FastImageCustom} from "components/FastImageCustom";
import FastImage from "react-native-fast-image";
import {dimensWidth, windowWidth} from "../../config/font";
import {Animations, format_dd_mm_yy, getParameterUrlDoc, isNullOrEmpty} from "../../utils/function";
import {AppBarCustom} from "components/AppBarCustom";
import {DocumentInteractive} from "services/database/models/DocumentInteractive";
import NetInfo from "@react-native-community/netinfo";
import {goToDocumentDetail} from "navigation/goToDetailNavigation";
import { SafeAreaView } from "react-native-safe-area-context";
import { Col, Row } from 'react-native-flex-grid';
import * as Animatable from 'react-native-animatable';
import {hideBottomSheet} from "../../redux/bottom_sheet/reducer";
import {showBottomSheet} from "../../redux/bottom_sheet/reducer";

// @ts-ignore
export const InteractiveScreen = ({navigation}) => {
    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);
    // @ts-ignore
    const translations = useSelector((state) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    const langId = currentLanguage === 'en' ? 1033 : 1066;
    // @ts-ignore
    const {isConnected} = useSelector((state) => state.netInfo);
    const dispatch = useDispatch();
    const animation = Animations[Math.floor(Math.random() * Animations.length)]
    const {isVisible} = useSelector((state: any) => state.bottomSheet);
    
    // @ts-ignore
    const itemRender = ({item, index}) => {
      
        // @ts-ignore
        return             <ScrollView horizontal style={[styles.viewScrollViewGrid, index % 2 == 0  && { backgroundColor: '#F1FAFF' }]} >
        <View>


          <View key={index} >
            <TouchableOpacity  onPress={() => goToDocumentDetail(navigation,item.ResourceUrl,isConnected,false)}>
            <Row style={styles.cellContent}>
              <Col style={{ padding: 10, width: 210, flexDirection: 'row' }}>
                <FastImage style={{
                  height: dimensWidth(15),
                  width: dimensWidth(15),
                  marginLeft: dimensWidth(2),
                }}
                  source={{ uri: item.Thumbnail }}
                  defaultSource={require('../../assets/images/icon_thumbDefault.png')}
                />
                <Text style={{ width: 320, marginLeft: 10, marginTop: 10, color: 'rgb(0, 104, 133)' }}>{item.StorageCode}</Text>
              </Col>
              <Col style={{ padding: 10, width: 100 }}>
                <Text style={{ width: 270, marginLeft: 80 }}>{item.Title}</Text>
              </Col>
              <Col style={{ marginLeft: -350, padding: 10 }}>
                {/* <Text style={{textAlign: 'center'}}>{item.Title}</Text> */}
              </Col>
              <Col style={{ padding: 10 }}>
                <Text style={{ marginLeft: 120 }}>{format_dd_mm_yy(item.Created)}</Text>
              </Col>
              <Col style={{ padding: 10 }}>
                <Text style={{ marginLeft: 55 }}>{item.Type}</Text>
              </Col>
            </Row>
            </TouchableOpacity >
          </View>
          <View>
          </View>
        </View>
      </ScrollView>
    }
    const getData = async (limit: number, offet: number, isOnline: any) => {
        if(isOnline)
        {
            const data = await getDocumentInteractive(langId, "Offset,Limit,LangId", offet, limit);
            if(data !=null)
            {
                DocumentInteractive.insertOrUpdateAll(data);
            }
            return data;
        }
        else
        {
            return DocumentInteractive.getAll(limit,offet);
        }
    }

    const onGoBack = useCallback(() => {
      dispatch(isVisible ? hideBottomSheet() : showBottomSheet());
      navigation.goBack();
    }, [])

    return <View style={{height:'100%',width:'100%',backgroundColor:'white'}}>
        <View style={{flex: 1, flexDirection: 'column',
         marginBottom: '10%',
         backgroundColor:'white',
         justifyContent:'center',alignContent:'center'}}>
          <View style={{alignItems:'center'}}>
          <Text style={{  fontSize:24,fontWeight:'600',marginTop: '3%'  }}>Văn bản tương tác</Text>
          <TouchableOpacity
          activeOpacity={1}
          style={{ backgroundColor: 'blue' }}
          onPress={onGoBack}
        >
          <FastImage
            style={styles.icon_back}
            resizeMode='contain'
            source={require('../../../src/assets/images/icon_closeForm.png')}
          />
        </TouchableOpacity>
          </View>
   
        <View style={styles.container}>
        <View style={{ alignItems: 'center' }}>
          <Text style={styles.title_header}>VBTT</Text>
        </View>



        <View style={styles.flexDirectionRowTab}>
          <View>
            <Row style={styles.cellHeader}>
              <Col style={[{
                padding: 7,
                marginLeft: 10,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}>
                <Text style={{ fontWeight: 'bold', width: 200 }}>Mã văn bản</Text></Col>
              <Col style={[{
                padding: 7,
                marginLeft: 100,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}><Text style={{ fontWeight: 'bold',width: 200, marginLeft: 30 }}>Tên văn bản</Text></Col>
              <Col style={[{
                padding: 7,
                marginLeft: 220,
                backgroundColor: '#f0f0f0',
                borderColor: '#ccc',
              }]}><Text style={{ fontWeight: 'bold', width: 200, marginLeft: -10 }}>Ngày tương tác</Text></Col>
              <Col style={styles.cellHeader}><Text style={{ fontWeight: 'bold' }}>Loại</Text></Col>
            </Row>
          </View>

        </View>
             
      <View style={{width:'97%',height:'100%',marginLeft:'1.2%'}}>
      <ListLoadMore numColumn={1} callData={getData} ItemRenderFlatlist={itemRender} limit={15} enableMoreData={true}/>
      
      </View>
      </View>
 

    </View>
    </View>
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    viewScrollViewGrid: {
      flexDirection: 'row',
      width: windowWidth,
  },
  cellContent: {
    width: windowWidth,
    height: 70
},
    title_header: {
        fontSize: 22,
        fontWeight: '600',
        top: 50,
        width: 250,
        textAlign: 'center',
        alignContent: 'center',
        justifyContent: 'center'
    },
    flexDirectionRowTab: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'baseline',
        marginLeft: 16,
        marginTop: 15,
        backgroundColor: '#F0F0F0',//colors.tab_bg_blue,
        borderColor: 'gray',
        padding: 0,
        width: windowWidth - 40,
        height: 60,
    },
    cellHeader: {
        padding: 7,
        width: windowWidth - 110,
        backgroundColor: '#f0f0f0',
        borderColor: '#ccc',
        marginLeft: 70,
        paddingHorizontal: 60
    },
    icon_back:{
      height: dimensWidth(10),
      width: dimensWidth(10),
      position: 'absolute',
      right: '-47%',
      bottom: '5%'
    },
});
