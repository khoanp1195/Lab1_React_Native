import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, useWindowDimensions, View } from "react-native";
import { ListLoadMore } from "components/ListLoadMore";
import { getComments, getDocumentInteractive } from "services/api/apiProvider";
import { useDispatch, useSelector } from "react-redux";
import { currentUserStore } from "../../config/constants";
import React, { useCallback } from "react";
import { FastImageCustom } from "components/FastImageCustom";
import FastImage from "react-native-fast-image";
import { dimensWidth, windowWidth } from "../../config/font";
import { Animations, format_dd_mm_yy, getParameterUrlDoc, isNullOrEmpty } from "../../utils/function";
import { AppBarCustom } from "components/AppBarCustom";
import HTML from 'react-native-render-html';
import { Comment } from "services/database/models/Comment";
import { goToDocumentDetail } from "navigation/goToDetailNavigation";
import { SafeAreaView } from "react-native-safe-area-context";
import { Col, Row } from 'react-native-flex-grid';
import * as Animatable from 'react-native-animatable';
import {showBottomSheet} from "../../redux/bottom_sheet/reducer";
import {hideBottomSheet} from "../../redux/bottom_sheet/reducer";
// @ts-ignore
export const CommentsScreen = ({ navigation }) => {
    // @ts-ignore
    const currentLanguage = useSelector((state) => state.languages.currentLanguage);
    // @ts-ignore
    const translations = useSelector((state) => state.languages.translations);
    const currentTranslations = translations[currentLanguage];
    // @ts-ignore
    const { isConnected } = useSelector((state) => state.netInfo);
    const dispatch = useDispatch();
    const {isVisible} = useSelector((state: any) => state.bottomSheet);
    // @ts-ignore
    const itemRender = ({ item, index }) => {
        const windowWidth = useWindowDimensions().width;
        const customHTMLElementModels = {
            label: {
                contentModel: 'flow', // Set the content model as 'flow' or 'block' as appropriate
                isOpaque: true, // Set to true if this element contains its own children
            },
        };
        const animation = Animations[Math.floor(Math.random() * Animations.length)]
        const ColorStatusToString = (itemp: any) => {
            if (item.Status == -1) {
              return '#FFCDCD'
            }
            if (item.IsApproved === null || item.IsApproved === 0) {
              return "#D1E9FF";
            }
            if (item.IsApproved === 1) {
              return "#D1FECE";
            }
      
            if ((item.IsApproved === 0)) {
              return "#FFCDCD";
            }
            else
              return "white"
          }
            //FormatTextStatusToString
    const FormatTextStatusToString = (itemp: any) => {
        if (item.Status == -1) {
          return 'Đã xóa'
        }
        if (item.IsApproved === null || item.IsApproved === 0) {
          return "Chờ phê duyệt";
        }
        if (item.IsApproved === 1) {
          return "Đã phê duyệt";
        }
  
        if ((item.IsApproved === 0)) {
          return "Bị từ chối";
        }
        else
          return "Nodata"
      }
        // @ts-ignore
        return        <ScrollView horizontal style={[styles.viewScrollViewGrid, index % 2 == 0 && { backgroundColor: '#F1FAFF' }]} >
        <View>
            <View key={index} >
                <TouchableOpacity onPress={() => goToDocumentDetail(navigation, item.ResourceUrl, isConnected, false)}>
                    <Row style={styles.cellContent}>
                        <Col style={{ padding: 10, width: 210, flexDirection: 'row' }}>
                            <FastImage style={{
                                height: dimensWidth(15),
                                width: dimensWidth(15),
                                marginLeft: dimensWidth(2),
                            }}
                                source={{ uri: item.Thumbnail }}
                                defaultSource={require('../../assets/images/icon_thumbDefault.png')}
                            />
                            <Text style={{ width: 320, marginLeft: 10, marginTop: 10, color: 'rgb(0, 104, 133)' }}>{item.Title}</Text>
                        </Col>
                        <Col style={{ padding: 10, width: 210 }}>
                            <Text style={{ width: 270, marginLeft: 80, flexDirection: 'row' }}>
                                <HTML source={{ html: item.Content }} contentWidth={windowWidth}
                                    // @ts-ignore
                                    customHTMLElementModels={customHTMLElementModels}
                                    ignoredDomTags={['label']}
                                />

                                {/* <HTML source={{ html: htmlContent }} /> */}
                            </Text>
                        </Col>
                        <Col style={{ marginLeft: -350, padding: 10 }}>
                            {/* <Text style={{textAlign: 'center'}}>{item.Title}</Text> */}
                        </Col>
                        <Col style={{ padding: 10, justifyContent: 'center' }}>
                            <Text style={{ marginLeft: '26%', textAlign: 'center', width: 170, height: 20 }}>{format_dd_mm_yy(item.Created)}</Text>
                        </Col>
                        <Col style={{ padding: 10, justifyContent: 'center' }}>
                            
                            <Text style={{ marginLeft: '-2%', width: 170, height: 20, borderRadius: 10, textAlign: 'center', backgroundColor: ColorStatusToString(item.IsApproved) }}>{FormatTextStatusToString(item.IsApproved)}</Text>
                        </Col>
                    </Row>
                </TouchableOpacity>

            </View>
            <View>
            </View>
        </View>
    </ScrollView>
    }
    // @ts-ignore
    const TextStatus = ({ item }) => {
        const statusMap = {
            '-1': { backgroundColor: '#FFCDCD', text: currentTranslations.status_delete },
            '0': { backgroundColor: '#D1E9FF', text: currentTranslations.status_approving },
            '1': { backgroundColor: '#D1FDCE', text: currentTranslations.status_approved },
            default: { backgroundColor: '#FFCDCD', text: currentTranslations.status_refuse },
        };

        // @ts-ignore
        const statusInfo = statusMap[item.Status] || statusMap.default;

        return (
            <View style={{ backgroundColor: statusInfo.backgroundColor, alignItems: 'center' }}>
                <Text style={styles.textStatus}>{statusInfo.text}</Text>
            </View>
        );
    };
    const getData = async (limit: number, offet: number, isOnline: any) => {
        if (isOnline) {
            const data = await getComments(offet, limit, {
                "Parameters": {
                    "CommentTitle": null,
                    "CommentStorageCode": null,
                    "CommentVersion": null,
                    "CommentDate": null,
                    "CommentIsApproved": null,
                    "CommentStatus": null
                }
            });
            if (data != null) {
                Comment.insertOrUpdateAll(data);
            }
            return data;
        } else {
            return Comment.getAll(limit, offet);
        }
    }
    const onGoBack = useCallback(() => {
        dispatch(isVisible ? hideBottomSheet() : showBottomSheet());
        navigation.goBack();
    }, [])
    return <View style={{ height: '100%', width: '100%' }}>
        <View style={{
            flex: 1, flexDirection: 'column',
            justifyContent: 'center', alignContent: 'center'
        }}>

            <View style={{ alignItems: 'center', backgroundColor: 'white' }}>
                <Text style={{ fontSize: 24, fontWeight: '600', marginTop: '3%' }}>Danh sách bình luận</Text>
                <TouchableOpacity
                    activeOpacity={1}
                    style={{ backgroundColor: 'blue' }}
                    onPress={onGoBack}
                >
                    <FastImage
                        style={styles.icon_back}
                        resizeMode='contain'
                        source={require('../../../src/assets/images/icon_closeForm.png')}
                    />
                </TouchableOpacity>
            </View>
            <View style={styles.container}>
                <View style={{ alignItems: 'center' }}>
                    <Text style={styles.title_header}>VBTT</Text>
                </View>



                <View style={styles.flexDirectionRowTab}>
                    <View>
                        <Row style={styles.cellHeader}>
                            <Col style={[{
                                padding: 7,
                                marginLeft: 10,
                                backgroundColor: '#f0f0f0',
                                borderColor: '#ccc',
                            }]}>
                                <Text style={{ fontWeight: 'bold', width: 200 }}>Tên văn bản</Text></Col>
                            <Col style={[{
                                padding: 7,
                                marginLeft: 100,
                                backgroundColor: '#f0f0f0',
                                borderColor: '#ccc',
                            }]}><Text style={{ fontWeight: 'bold', width: 200, marginLeft: 30 }}>Nội dung bình luận</Text></Col>
                            <Col style={[{
                                padding: 7,
                                marginLeft: 220,
                                backgroundColor: '#f0f0f0',
                                borderColor: '#ccc',
                            }]}><Text style={{ fontWeight: 'bold', width: 200, marginLeft: -10 }}>Ngày bình luận</Text></Col>
                            <Col style={styles.cellHeader}><Text style={{ fontWeight: 'bold' }}>Trạng thái</Text></Col>
                        </Row>
                    </View>

                </View>

                <View style={{ width: '97%', height: '100%', marginLeft: '1.2%' }}>
                    <ListLoadMore numColumn={1} callData={getData} ItemRenderFlatlist={itemRender} enableMoreData={true} limit={15} />
                </View>
            </View>

        </View>
    </View>
}
const styles = StyleSheet.create({
    root: {
        flexDirection: 'row',
        paddingHorizontal: 20,
        paddingVertical: 10
    },
    viewScrollViewGrid: {
        flexDirection: 'row',
        width: windowWidth,
    },
    flexDirectionRowTab: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'baseline',
        marginLeft: 16,
        marginTop: '1%',
        backgroundColor: '#F0F0F0',//colors.tab_bg_blue,
        borderColor: 'gray',
        padding: 0,
        width: windowWidth - 40,
        height: 60,
    },
    cellHeader: {
        padding: 7,
        width: windowWidth - 110,
        backgroundColor: '#f0f0f0',
        borderColor: '#ccc',
        marginLeft: 70,
        paddingHorizontal: 60
    },
    title_header: {
        fontSize: 22,
        fontWeight: '600',
        top: 50,
        width: 250,
        textAlign: 'center',
        alignContent: 'center',
        justifyContent: 'center'
    },
    img: {
        height: 45,
        wight: 30,
        borderRadius: dimensWidth(0)
    },
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    textStatus: {
        marginTop: 5,
        paddingHorizontal: 10,
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        color: 'black',
    },
    textTilte: {
        color: 'black',
        fontSize: 14,
        fontFamily: 'heritage_regular',
        lineHeight: 15,

    },
    textCreated: {
        fontFamily: 'heritage_regular',
        lineHeight: 15,
        color: '#7B7B7B',
        marginLeft: '10%'
    },
    icon_back: {
        height: dimensWidth(10),
        width: dimensWidth(10),
        position: 'absolute',
        right: '-47%',
        bottom: '5%'
    },
    cellContent: {
        width: windowWidth,
        height: 70
    },
})

