import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import TextCusTom from 'components/TextCusTom'
import { TouchableOpacity } from 'react-native-gesture-handler'
import {format_dd_mm_yy} from "../../../utils/function";
import {FontSize} from "../../../config/font";
import colors from "../../../config/colors";
import ThumbnailImage from "./ThumbnailImage";
import * as Animatable from 'react-native-animatable';
import { FastImageCustom } from 'components/FastImageCustom';

const DocumentItem = ({gotoDetail, item, index}: any) => {
    const formatDate = format_dd_mm_yy(item?.IssueDate)
    return (
        <TouchableOpacity 
        onPress={() => gotoDetail(item)}
         style={[styles.itemNewDocuments, 
         { backgroundColor: 'rgba(0, 0, 0, 0)' }]}>
        <View style={styles.itemNewDocumentsChild}>
            <ThumbnailImage urlOnline={item?.Thumbnail} styleImg={styles.itemNewDocumentsChild}/>
        </View>
        <TextCusTom i18nKey={item?.Title} style={styles.titleItemNewDoc} numberOfLines={1}/>
        <TextCusTom i18nKey={formatDate} style={styles.dateItemNewDoc}/>
      </TouchableOpacity>
        )
}

export default DocumentItem

const styles = StyleSheet.create({
    itemContainer:{
        flexDirection: 'row',
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderRadius: 5,
        width: 210,
        height: 350,
        marginLeft: '2%',
        
        shadowColor: "#000",
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
    },
    imgThumbnail:{
        height: 200,
        width: 160
    },
    cap1:{
        fontSize: FontSize.SMALL,
        color: colors.text_grey26,
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center'
    },
    cap2:{
        fontSize: FontSize.SMALL,
        color: '#7B7B7B',
        fontWeight: '400',
        marginTop: 7,
        textAlign: 'center'
    },
    itemNewDocumentsChild: {
        flexDirection: 'row',
        backgroundColor: 'white',
        borderRadius: 3,
        width: 165,
        height: 230,
        borderColor:'lightgray',
        borderWidth: 0.5,
        position: 'absolute',
      },
      itemNewDocuments: {
        flexDirection: 'row',
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderRadius: 5,
        width: 210,
        height: 350,
        marginLeft: '2%',
        
        shadowColor: "#000",
        shadowOffset: {
          width: 0,
          height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
    
      },
    
      titleItemNewDoc: {
        position: 'absolute',
        bottom: 70,
        right: 20,
        width:190,
        textAlign: 'center',
        color: '#262626',
        fontSize: 15,  
      },
      dateItemNewDoc: {
        position: 'absolute',
        textAlign: 'center',
        alignItems: 'center',
        bottom: 40,
        color: '#7B7B7B',    
        right: 80,
        
      },
})
