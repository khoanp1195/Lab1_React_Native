import {Image, StyleSheet, Text, TouchableOpacity, View} from "react-native";
import React from "react";

// @ts-ignore
export const AppBarCustom = ({title, navigation, RightControl, onPress,isSearchDetail}) => {
    console.log("title - appbarcustom: " + title)
    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.touch} onPress={() => {
                if (onPress == null) {
                    navigation.pop();
                }
                else {
                    onPress();
                }
            }}>
                {
                    isSearchDetail ? (
                        <Text style={{fontSize: 20,marginLeft:'10%',color:'white',fontWeight:400}}>Tìm kiếm</Text>
                    ) :(     
                        <Image
                        style={styles.image}
                        source={require('assets/images/icon_back.png')}
                        resizeMode="contain"
                    />)
                }
           
            </TouchableOpacity>
            <Text style={styles.text}>{title}</Text>
            {RightControl != null && (
                <RightControl/>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    text: {
        marginTop: 5,
        color: '#006885',
        fontSize: 20,
        fontFamily: 'heritage_bold',
        lineHeight: 24,
        flex: 1,
        fontWeight: '600'
        

    },
    image: {
        height: 30,
        width: 30,
        marginLeft: 10
    },
    touch: {
        padding: 6,
        marginTop:'1%',
        zIndex:1
    },
    rightControl: {
        // Tùy chỉnh kiểu dáng của control bên phải ở đây
    },
    container: {
        height: '12%',
        width: '100%',
        backgroundColor: '#006885',
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexDirection: 'row',
        
    }
});
